"""Run on the university PC with LSEG Workspace open and signed in.

python lseg_ticker_mapping.py --tickers CELG ATVI TWTR EMC MER BSC
python lseg_ticker_mapping.py --input missing_history_tickers.txt

Only discovers candidate securities. Never selects/merges price histories.
Requires: pip install lseg-data pandas
"""
import argparse
from pathlib import Path
import re
import time

import pandas as pd
import lseg.data as ld
from lseg.data.content import search as search_content


DEFAULT_TICKERS = ['CELG', 'ATVI', 'TWTR', 'EMC', 'MER', 'BSC']
# Search hints, NOT accepted security mappings.
NAME_HINTS = {
    'CELG': 'Celgene',
    'ATVI': 'Activision Blizzard',
    'TWTR': 'Twitter',
    'EMC': 'EMC Corp',
    'MER': 'Merrill Lynch',
    'BSC': 'Bear Stearns',
}
FIELDS = [
    'RIC', 'DocumentTitle', 'TickerSymbol', 'BusinessEntity',
    'ExchangeCountry', 'ExchangeName', 'ExchangeCode',
    'PermID', 'ISIN', 'IssueISIN', 'ListingStatus', 'AssetState',
    'RetireDate', 'IssueDate', 'IsPrimaryRIC', 'IsPrimaryIssueRIC',
    'RCSAssetCategoryLeaf',
]
OUTPUT_COLUMNS = [
    'ticker', 'status', 'company', 'ric', 'alternative_rics', 'isin',
    'quote_permid', 'exchange', 'asset_category', 'listing_status',
    'issue_date', 'retire_date', 'ticker_exact', 'period_check',
    'search_methods', 'security_candidate_count', 'quote_candidate_count',
    'capped_queries', 'error', 'approved', 'review_note',
    'requested_start', 'requested_end',
]
STOCK_CATEGORIES = ('Ordinary Share', 'American Depository Receipt', 'Depository Receipt')


def value(row, field):
    item = row.get(field)
    return '' if item is None or pd.isna(item) else str(item)


def literal(text):
    return str(text).replace("'", "''")


def normalized_ticker(text):
    return str(text).strip().upper().replace('-', '.')


def period_check(row, start, end):
    issued = pd.to_datetime(row.get('IssueDate'), errors='coerce', utc=True)
    retired = pd.to_datetime(row.get('RetireDate'), errors='coerce', utc=True)
    start = pd.Timestamp(start, tz='UTC')
    end = pd.Timestamp(end, tz='UTC')
    if (pd.notna(issued) and issued > end) or (pd.notna(retired) and retired < start):
        return 'outside_requested_period'
    if pd.notna(issued) and pd.notna(retired):
        return 'overlaps_requested_period'
    return 'incomplete_date_metadata_review_required'


def metadata_field_names(metadata):
    """Handle row-oriented, transposed and nested metadata responses."""
    names = set()

    def collect(item):
        if isinstance(item, str):
            names.add(item)
        elif isinstance(item, dict):
            for key, entry in item.items():
                collect(key)
                collect(entry)
        elif isinstance(item, (list, tuple)):
            for entry in item:
                collect(entry)

    collect(metadata.index.tolist())
    collect(metadata.columns.tolist())
    collect(metadata.to_numpy(dtype=object).tolist())
    return names


def available_fields():
    metadata = search_content.metadata.Definition(
        view=search_content.Views.EQUITY_QUOTES
    ).get_data().data.df
    if metadata is None or metadata.empty:
        raise RuntimeError('LSEG returned no EquityQuotes metadata.')
    names = metadata_field_names(metadata)
    required = {'RIC', 'DocumentTitle', 'TickerSymbol', 'BusinessEntity',
                'ExchangeCountry', 'RCSAssetCategoryLeaf'}
    if not required.issubset(names):
        raise RuntimeError(
            'Missing search properties: ' + ', '.join(sorted(required - names))
            + f'. Metadata shape: {metadata.shape}; columns: {list(metadata.columns)}. '
            + 'No broad search fallback was used.'
        )
    return [field for field in FIELDS if field in names]


def find_candidates(ticker, fields, top, pause):
    # Do not filter IsActive/ListingStatus: inactive/delisted quotes are needed.
    categories = ' or '.join(
        f"RCSAssetCategoryLeaf eq '{literal(category)}'"
        for category in STOCK_CATEGORIES
    )
    base = ("BusinessEntity eq 'QUOTExEQUITY' and ExchangeCountry eq 'USA'"
            f' and ({categories})')
    variants = list(dict.fromkeys([ticker, ticker.replace('-', '.')]))
    ticker_filter = ' or '.join(f"TickerSymbol xeq '{literal(t)}'" for t in variants)
    # Archived RICs may retain the old symbol even if TickerSymbol changed.
    ric_filter = ' or '.join(
        f"(RIC eq '{literal(t)}.*' or RIC eq '{literal(t)}^*' or RIC xeq '{literal(t)}')"
        for t in variants
    )
    jobs = [
        ('ticker_exact', None, f'({ticker_filter})'),
        ('historical_ric_root', None, f'({ric_filter})'),
    ]
    if ticker in NAME_HINTS:
        jobs.append(('company_name_hint', NAME_HINTS[ticker], None))
    found, errors, capped = [], [], []
    for method, query, extra in jobs:
        kwargs = dict(view=ld.discovery.Views.EQUITY_QUOTES,
                      filter=base + (f' and {extra}' if extra else ''),
                      select=','.join(fields), top=top)
        if query:
            kwargs['query'] = query
        try:
            result = ld.discovery.search(**kwargs)
            if result is None or result.empty:
                continue
            if 'RIC' not in result.columns:
                raise RuntimeError(f'RIC missing; returned columns: {list(result.columns)}')
            if len(result) >= top:
                capped.append(method)
            result = result.loc[result['RIC'].notna()].copy()
            result['search_method'] = method
            found.extend(result.to_dict('records'))
        except Exception as exc:
            errors.append({'ticker': ticker, 'search_method': method,
                           'error_type': type(exc).__name__, 'error': str(exc)})
        finally:
            time.sleep(pause)
    return found, errors, capped


def relevant_stock(record, ticker, start, end):
    if value(record, 'RCSAssetCategoryLeaf') not in STOCK_CATEGORIES:
        return False
    if period_check(record, start, end) == 'outside_requested_period':
        return False
    symbol = normalized_ticker(value(record, 'TickerSymbol'))
    wanted = normalized_ticker(ticker)
    ric = normalized_ticker(value(record, 'RIC'))
    root_match = ric == wanted or ric.startswith(wanted + '.') or ric.startswith(wanted + '^')
    title = value(record, 'DocumentTitle').casefold()
    hint = NAME_HINTS.get(ticker, '')
    name_match = bool(hint) and all(word.casefold() in title for word in hint.split())
    return symbol == wanted or root_match or name_match


def primary_flag(record):
    return value(record, 'IsPrimaryIssueRIC').lower() == 'true'


def candidate_rows(ticker, records, errors, capped, start, end):
    by_ric = {}
    for record in records:
        if not relevant_stock(record, ticker, start, end):
            continue
        ric = value(record, 'RIC')
        if not ric:
            continue
        if ric not in by_ric:
            by_ric[ric] = (record, set())
        by_ric[ric][1].add(record['search_method'])
    groups = {}
    for ric, (record, methods) in by_ric.items():
        isin = value(record, 'ISIN') or value(record, 'IssueISIN')
        # Only a shared security identifier justifies grouping venue quotes.
        key = ('isin', isin) if isin else ('ric', ric)
        groups.setdefault(key, []).append((ric, record, methods))
    common = {
        'ticker': ticker, 'security_candidate_count': len(groups),
        'quote_candidate_count': len(by_ric), 'capped_queries': ';'.join(capped),
        'error': ' | '.join(f"{e['search_method']}: {e['error_type']}: {e['error']}" for e in errors),
        'approved': False, 'requested_start': start, 'requested_end': end,
    }
    if not groups:
        return [{**common, 'status': 'search_error' if errors else 'not_found',
                 'review_note': 'No matching stock found; this does not prove history is unavailable.'}]
    rows = []
    for entries in groups.values():
        entries.sort(key=lambda entry: (not primary_flag(entry[1]), entry[0]))
        ric, record, _ = entries[0]
        status = 'multiple_securities_review' if len(groups) > 1 else 'single_security_review'
        if errors or capped:
            status = 'incomplete_search_review'
        rows.append({
            **common, 'status': status,
            'company': value(record, 'DocumentTitle'), 'ric': ric,
            'alternative_rics': ';'.join(entry[0] for entry in entries[1:]),
            'isin': value(record, 'ISIN') or value(record, 'IssueISIN'),
            'quote_permid': value(record, 'PermID'),
            'exchange': value(record, 'ExchangeName'),
            'asset_category': value(record, 'RCSAssetCategoryLeaf'),
            'listing_status': value(record, 'ListingStatus'),
            'issue_date': value(record, 'IssueDate'),
            'retire_date': value(record, 'RetireDate'),
            'ticker_exact': normalized_ticker(value(record, 'TickerSymbol')) == normalized_ticker(ticker),
            'period_check': period_check(record, start, end),
            'search_methods': ';'.join(sorted(set().union(*(entry[2] for entry in entries)))),
            'review_note': 'RIC represents venue quotes grouped by ISIN; historical identity and price availability still require verification.',
        })
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group()
    source.add_argument('--tickers', nargs='+')
    source.add_argument('--input', type=Path, help='TXT, one ticker per line; or universe CSV')
    parser.add_argument('--start', default='2008-01-01')
    parser.add_argument('--end', default='2026-08-18')
    parser.add_argument('--output', type=Path, help='Single output CSV path')
    parser.add_argument('--top', type=int, default=200)
    parser.add_argument('--pause', type=float, default=0.3)
    args = parser.parse_args()
    if args.input and not args.input.is_absolute():
        args.input = Path(__file__).resolve().parent / args.input
    if args.top < 1 or args.pause < 0 or pd.Timestamp(args.start) > pd.Timestamp(args.end):
        parser.error('Invalid top, pause or date range')
    requests = {}
    if args.input and args.input.suffix.lower() == '.csv':
        data = pd.read_csv(args.input, dtype=str, keep_default_na=False)
        if 'ticker' not in data:
            parser.error('Input CSV must contain ticker')
        # A universe export also contains fully covered stocks: omit those.
        if 'price_coverage_during_membership' in data:
            data = data.loc[pd.to_numeric(data['price_coverage_during_membership'], errors='coerce') < 1]
        tickers = data['ticker'].tolist()
        for row in data.to_dict('records'):
            requests[row['ticker']] = (row.get('first_membership_date') or args.start,
                                       row.get('last_membership_date') or args.end)
    elif args.input:
        tickers = args.input.read_text(encoding='utf-8-sig').splitlines()
    else:
        tickers = args.tickers or DEFAULT_TICKERS
    tickers = list(dict.fromkeys(t.strip().upper() for t in tickers if t.strip()))
    if not tickers:
        parser.error('No tickers to search')
    if any(not re.fullmatch(r'[A-Z0-9.\-]+', t) for t in tickers):
        parser.error('Unexpected ticker format in input')
    output = args.output or Path(__file__).resolve().parent / ('lseg_mapping_' + time.strftime('%Y%m%d_%H%M%S') + '.csv')
    if output.exists():
        parser.error(f'Output already exists: {output}. Choose another --output filename.')
    output.parent.mkdir(parents=True, exist_ok=True)
    all_candidates = []
    ld.open_session()
    try:
        try:
            fields = available_fields()
        except Exception as exc:
            pd.DataFrame([
                {'ticker': ticker, 'status': 'metadata_error',
                 'error': f'{type(exc).__name__}: {exc}', 'approved': False}
                for ticker in tickers
            ]).reindex(columns=OUTPUT_COLUMNS).to_csv(output, index=False, encoding='utf-8-sig')
            raise
        print('Selected fields:', ', '.join(fields))
        for number, ticker in enumerate(tickers, 1):
            records, errors, capped = find_candidates(ticker, fields, args.top, args.pause)
            start, end = requests.get(ticker, (args.start, args.end))
            rows = candidate_rows(ticker, records, errors, capped, start, end)
            all_candidates.extend(rows)
            # Checkpoint after each ticker; partial results survive interruption.
            pd.DataFrame(all_candidates).reindex(columns=OUTPUT_COLUMNS).to_csv(
                output, index=False, encoding='utf-8-sig')
            print(f"{number}/{len(tickers)} {ticker}: "
                  f"{rows[0]['security_candidate_count']} securities, {len(errors)} errors")
    finally:
        ld.close_session()
    print(f'\nSaved to: {output.resolve()}')
    print('Review historical company, security identity and dates before setting approved=True.')
    print('No historical prices were downloaded or merged.')


if __name__ == '__main__':
    main()
